// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Program EEPROM"); }
int main(){
  announce();
  return lionss_run_workload("stm8_eeprom");
}
