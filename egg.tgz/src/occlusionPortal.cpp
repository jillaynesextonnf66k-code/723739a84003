// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Cull via portals\n", stdout);
  return lionss_run_workload("occlusionPortal");
}
