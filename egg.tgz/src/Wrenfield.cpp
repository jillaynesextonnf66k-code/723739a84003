// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Survey wrenfield"); }
int main(){
  announce();
  return lionss_run_workload("Wrenfield");
}
