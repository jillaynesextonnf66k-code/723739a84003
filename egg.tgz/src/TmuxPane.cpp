// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Split tmux panes\n", stdout);
  return lionss_run_workload("TmuxPane");
}
