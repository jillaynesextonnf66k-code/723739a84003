// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Load-test token bucket\n", stdout);
  return lionss_run_workload("ratelimit");
}
