// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Autotune PID gains"); }
int main(){
  announce();
  return lionss_run_workload("PidAutotune");
}
